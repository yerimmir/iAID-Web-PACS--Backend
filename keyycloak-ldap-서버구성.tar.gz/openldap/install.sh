ldapadd -Y EXTERNAL -H ldapi:/// -f openldap/schema/dicom.ldif
ldapadd -Y EXTERNAL -H ldapi:/// -f openldap/schema/dcm4che.ldif
tr -d \\r < /openldap/schema/dcm4chee-archive.ldif | sudo ldapadd -Y EXTERNAL -H ldapi:///
ldapadd -Y EXTERNAL -H ldapi:/// -f /openldap/schema/dcm4chee-archive-ui.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/schema/dicom.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/init-baseDN.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/init-config.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/default-config.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/default-ui-config.ldif
ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/add-vendor-data.ldif


# ldapmodify -Y EXTERNAL -H ldapi:/// -f openldap/schema/dicom.ldif
# ldapmodify -Y EXTERNAL -H ldapi:/// -f openldap/schema/dcm4che.ldif
# tr -d \\r < /openldap/schema/dcm4chee-archive.ldif | sudo ldapadd -Y EXTERNAL -H ldapi:///
# ldapadd -Y EXTERNAL -H ldapi:/// -f /openldap/schema/dcm4chee-archive-ui.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/schema/dicom.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/init-baseDN.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/init-config.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/default-config.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/default-ui-config.ldif
# ldapadd -xw change_me -H ldap://localhost:1389 -D cn=admin,dc=dcm4che,dc=org -f /openldap/ldifs/add-vendor-data.ldif